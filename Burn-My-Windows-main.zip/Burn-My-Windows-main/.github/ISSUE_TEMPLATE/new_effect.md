---
# SPDX-FileCopyrightText: Simon Schneegans <code@simonschneegans.de>
# SPDX-License-Identifier: CC-BY-4.0

name: New Effect
about: Suggest a new effect for the Burn-My-Windows Extension.
title: ''
labels: 'new effect'
assignees: ''
---

## The Idea
Please describe your idea as detailed as possible.
It would be great if you could add a drawing or any other kind of mock-up to illustrate your idea!

## Window Closing vs. Window Opening
Make sure to describe how the effect could be reversed, so how should a window disappear and how should it appear.

## References
It would be great if you could provide some video references (e.g. YouTube links) if your idea is based on something which - for example - exists in movies.